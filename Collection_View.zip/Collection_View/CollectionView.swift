//
//  CollectionView.swift
//  Collection_View
//
//  Created by Hence4th on 25/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class CollectionView: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
