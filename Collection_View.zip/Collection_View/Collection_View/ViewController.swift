//
//  ViewController.swift
//  Collection_View
//
//  Created by Hence4th on 25/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var photocell: UICollectionViewCell!
    @IBOutlet weak var clctnView: UICollectionView!
    var arrBool : [Bool] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for _ in 0...30{
            arrBool.append(false)
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
}

extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrBool.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        print("Select")
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCellCollectionViewCell", for: indexPath)as! PhotoCellCollectionViewCell
        if arrBool[indexPath.row]{
            cell.btncell.setTitle("Button selected", for: .normal)
        }else{
            cell.btncell.setTitle("Button unselected", for: .normal)

        }
        cell.btncell.tag = indexPath.row
        cell.btncell.addTarget(self, action: #selector(btnActSelect(_:)), for: .touchUpInside)
//                 cell.btncell.addTarget(self, action: #selector(deselect(_:)), for: .touchUpInside)
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        print("Button")
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.view.frame.width - 64)/3, height: (self.view.frame.width - 64)/3)
    }
    
    
    @objc func btnActSelect(_ sender: UIButton){
        arrBool[sender.tag] = !arrBool[sender.tag]
//        clctnView.reloadData()
        clctnView.reloadItems(at: [arrBool.[indexpath.row][])
    }

    
            }}
