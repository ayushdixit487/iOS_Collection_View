//
//  PhotoCellCollectionViewCell.swift
//  Collection_View
//
//  Created by Hence4th on 25/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class PhotoCellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var btncell: UIButton!
}
